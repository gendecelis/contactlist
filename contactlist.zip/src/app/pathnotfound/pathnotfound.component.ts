import { Component } from '@angular/core';

@Component({
  selector: 'app-pathnotfound',
  templateUrl: './pathnotfound.component.html',
  styleUrls: ['./pathnotfound.component.scss']
})
export class PathnotfoundComponent {

}
