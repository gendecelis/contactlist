import { Component, OnInit } from '@angular/core';
import { Contact } from '../contact';
import { ContactService } from '../contact.service';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.scss']
})
export class ContactComponent implements OnInit {

  constructor(private contactService: ContactService) { }

  // The currently selected contact for editing
  selectedContact: Contact | undefined;

  // Array to store the fetched contacts
  contacts!: Contact[];

  ngOnInit() {
    // Fetch the list of contacts when the component initializes
    this.fetchContacts();
  }

  // Add or update a contact
  addContact(contact: Contact) {
    if (contact.id) {
      // If the contact has an ID, update it
      this.contactService.updateContact(contact.id, contact).subscribe(() => {
        // After updating, fetch the updated list of contacts
        this.fetchContacts();
      });
    } else {
      // If the contact has no ID, add it as a new contact
      this.contactService.addContact(contact).subscribe(() => {
        // After adding, fetch the updated list of contacts
        this.fetchContacts();
      });
    }
  }

  // Fetch the list of contacts
  fetchContacts() {
    this.contactService.getContacts().subscribe((contacts) => {
      // Update the contacts array with the fetched data
      this.contacts = contacts;
    });
  }

  // Delete a contact
  deleteContact(id: number) {
    this.contactService.deleteContact(id).subscribe(() => {
      // After deleting, fetch the updated list of contacts
      this.fetchContacts();
    });
  }

  // Set the selectedContact for editing
  editContact(contact: Contact) {
    this.selectedContact = contact;
  }
}
