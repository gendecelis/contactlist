import { Component, EventEmitter, Input, Output, TemplateRef } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { Contact } from 'src/app/contact';

@Component({
  selector: 'app-contact-list',
  templateUrl: './contact-list.component.html',
  styleUrls: ['./contact-list.component.scss']
})
export class ContactListComponent {
  // Input property for the list of contacts to display
  @Input() contacts!: Contact[];
  
  // Output event for deleting a contact
  @Output() deleteEvent = new EventEmitter<number>();

  // Output event for editing a contact
  @Output() editEvent = new EventEmitter<Contact>();

  // Stores the modal reference
  modalRef?: BsModalRef;

  constructor(private modalService: BsModalService) { }

  // Stores the ID of the contact being interacted with
  id!: number;

  // Opens the modal with a template and stores the selected contact ID
  openModal(id: number, template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
    this.id = id;
  }

  // Confirms the action and emits the delete event
  confirm(): void {
    this.modalRef?.hide();
    this.deleteEvent.emit(this.id);
  }

  // Declines the action and hides the modal
  decline(): void {
    this.modalRef?.hide();
  }

  // Emits the edit event with the selected contact
  editContact(contact: Contact) {
    this.editEvent.emit(contact);
  }
}
