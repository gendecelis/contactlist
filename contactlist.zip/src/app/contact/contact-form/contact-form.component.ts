import { Component, EventEmitter, Input, OnChanges, Output } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Contact } from 'src/app/contact';

@Component({
  selector: 'app-contact-form',
  templateUrl: './contact-form.component.html',
  styleUrls: ['./contact-form.component.scss']
})
export class ContactFormComponent implements OnChanges {
  // Input property for the selected contact to edit
  @Input() selectedContact: Contact | undefined;

  // Output event for submitting the contact form
  @Output() submitContact = new EventEmitter<Contact>();

  // Stores the contact data for the form
  contact: Contact = { id: 0, name: '', email: '', contactNo: '' };

  ngOnChanges() {
    // When the selectedContact input changes, update the form's contact data
    this.contact = { ...this.selectedContact! };
  }

  // Handles form submission
  onSubmit(contactForm: NgForm) {
    // Emit the updated or new contact data
    this.submitContact.emit(this.contact);

    // Reset the form fields and selectedContact property
    this.resetForm(contactForm);
  }

  // Resets the form fields and selectedContact property
  resetForm(contactForm: NgForm) {
    contactForm.reset();
    this.selectedContact = undefined;
  }
}
