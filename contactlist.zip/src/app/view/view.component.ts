import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PostsService } from '../posts.service';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css'],
})
export class ViewComponent {
  users: any;

  foundData: any;

  constructor(
    private route: ActivatedRoute,
    private postService: PostsService,
    private routers: Router
  ) {}

  ngOnInit(): void {
    this.getData();
  }

  getData() {
    this.users = this.postService.storeData();

    this.getUserDetails();
  }

  getUserDetails(): void {
    const userId = Number(this.route.snapshot.paramMap.get('id'));

    const foundUser = this.users.find((user: any) => user.id === userId);

    this.foundData = foundUser;
  }

  goBack(): void {
    this.routers.navigate(['home'], { replaceUrl: true });

    const status: boolean = true;

    this.postService.fetchStatus(status);
  }
}
