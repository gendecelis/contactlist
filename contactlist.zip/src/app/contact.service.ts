import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment.development';
import { Contact } from './contact';

@Injectable({
  providedIn: 'root'
})
export class ContactService {

  constructor(private httpClient: HttpClient) { }
  
  // Get the base URL from the environment configuration
  private baseUrl = environment.baseUrl;

  // Fetches a list of contacts from the API
  getContacts(): Observable<Contact[]> {
    return this.httpClient.get<Contact[]>(`${this.baseUrl}`);
  }

  // Fetches a single contact by ID from the API
  getContact(id: number): Observable<Contact> {
    return this.httpClient.get<Contact>(`${this.baseUrl}/${id}`);
  }

  // Adds a new contact to the API
  addContact(contact: Contact): Observable<Contact> {
    return this.httpClient.post<Contact>(this.baseUrl, contact);
  }

  // Deletes a contact by ID from the API
  deleteContact(id: number): Observable<Contact> {
    return this.httpClient.delete<Contact>(`${this.baseUrl}/${id}`);
  }

  // Updates an existing contact with new data using the PUT method
  updateContact(id: number, contact: Contact): Observable<Contact> {
    return this.httpClient.put<Contact>(`${this.baseUrl}/${id}`, contact);
  }
}
