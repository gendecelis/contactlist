import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ContactDetailsComponent } from './contact-details/contact-details.component';
import { ContactComponent } from './contact/contact.component';
import { PathnotfoundComponent } from './pathnotfound/pathnotfound.component';

const routes: Routes = [
  { path: '', component: ContactComponent },
  { path: 'contact/:id', component: ContactDetailsComponent },
  { path: '**', component: PathnotfoundComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
