import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Contact } from '../contact';
import { ContactService } from '../contact.service';

@Component({
  selector: 'app-contact-details',
  templateUrl: './contact-details.component.html',
  styleUrls: ['./contact-details.component.scss']
})
export class ContactDetailsComponent implements OnInit {
  constructor(private route: ActivatedRoute, private contactService: ContactService) { }
  
  // Extract the contact ID from the route parameters
  id = this.route.snapshot.params['id'];
  
  // Stores the fetched contact details
  contact?: Contact;

  ngOnInit() {
    // Fetch the contact details from the service based on the extracted ID
    this.contactService.getContact(this.id).subscribe((data) => {
      this.contact = data;
    });
  }
}
