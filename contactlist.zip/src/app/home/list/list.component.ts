import { Component, Input, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css'],
})
export class ListComponent {
  constructor() {}

  @Input() userData: any;

  @Output() userViewId: EventEmitter<any> = new EventEmitter<any>();
  @Output() userUpdateId: EventEmitter<any> = new EventEmitter<any>();
  @Output() userDeleteId: EventEmitter<any> = new EventEmitter<any>();

  viewUserDetail(id: number) {
    this.userViewId.emit(id);
  }

  updateUserDetail(id: number) {
    this.userUpdateId.emit(id);
  }

  deleteUserDetail(id: number) {
    this.userDeleteId.emit(id);
  }
}
