import { Component, OnInit } from '@angular/core';
import { PostsService } from '../posts.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent {
  users: any;

  idUser: any;

  foundUser: any;

  deleteUser: any;

  constructor(private postService: PostsService, private router: Router) {}

  ngOnInit(): void {
    if (this.postService.passStatus()) {
      this.users = this.postService.storeData();
    } else {
      this.fetchUser();
    }
  }

  fetchUser() {
    this.postService.getPost().subscribe((data: any) => {
      this.users = data;

      this.copyUserData();
    });
  }

  postUser(newUser: any, updateStatus: boolean) {
    //Post and Update

    if (updateStatus) {
      if (this.idUser > 10) {
        const index = this.users.findIndex(
          (user: any) => user.id === this.idUser
        );

        if (index !== -1) {
          this.users[index] = { ...newUser, id: this.idUser };
        }
      } else {
        this.postService

          .updatePost(this.idUser, newUser)

          .subscribe((updatedUser: any | null) => {
            if (updatedUser) {
              const index = this.users.findIndex(
                (user: any) => user.id === updatedUser.id
              );

              if (index !== -1) {
                this.users[index] = updatedUser;
              }
            }
          });
      }
    } else {
      this.postService.createPost(newUser).subscribe((data: any) => {
        const lastId = this.users[this.users.length - 1]?.id || 0;

        const newData = { ...data, id: lastId + 1 };

        this.users.push(newData);

        this.copyUserData();
      });
    }
  }

  copyUserData() {
    this.postService.copyUser(this.users);
  }

  getViewUserId(id: any) {
    this.idUser = id;

    this.router.navigate(['view', this.idUser]);
  }

  getUpdateUserId(id: number) {
    //find User Id

    this.idUser = id;
    const found = this.users.find((user: any) => user.id === id);
    this.foundUser = found;
  }

  getDeleteUserId(id: number) {
    //delete user

    this.idUser = id;
    const found = this.users.find((user: any) => user.id === id);
    this.deleteUser = found;
    const confirmDelete = window.confirm(
      'Are you sure you want to delete this user?'
    );
    if (confirmDelete) {
      this.deleteUserData();
    }
  }

  deleteUserData() {
    this.postService.deletePost(this.idUser).subscribe(() => {
      const index = this.users.findIndex(
        (user: any) => user.id === this.idUser
      );

      if (index !== -1) {
        this.users.splice(index, 1);
      }
    });
  }
}
